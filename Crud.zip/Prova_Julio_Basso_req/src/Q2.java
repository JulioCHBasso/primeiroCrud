
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jbasso
 */
public class Q2 {
    public static void main(String[] args) {
        String s="";
        int opcao=0;
        float num[][] = new float[3][3];
        float total=0;
        
        JOptionPane.showMessageDialog(null, "Bem Vindo ao Sistema Café");
        do{
        s=JOptionPane.showInputDialog(null," Digite 1 - café expresso; 2 - café capuccino; 3 - leite com café; 4 - totalizar vendas");
        opcao = Integer.parseInt(s);
        if(opcao == 1){
            JOptionPane.showMessageDialog(null, "café expresso vendido com sucesso ");
            num[0][0]++;
            num[0][1]+=0.75;
            total += num[0][1];
        }else if (opcao == 2 ){
            JOptionPane.showMessageDialog(null, "café capuccino vendido com sucesso ");
            num[1][0]++;
            num[1][1]+=1;
            total += num[1][1];
        }else if(opcao == 3){
            JOptionPane.showMessageDialog(null, "leite com café vendido com sucesso ");
            num[2][0]++;
            num[2][1]+=1;
            total += num[2][1];        
        }else if (opcao == 4 ){
        JOptionPane.showMessageDialog(null, "Fechando o caixa aguardade ");
        }
        
        }while(opcao!=4);
        
        JOptionPane.showMessageDialog(null,"A quantidade de café expresso vendido é: "+num[0][0]+"com o valor total "+num[0][1]+"R$\n"
                + "A quantidade de café capuccino vendido é: "+num[1][0]+"com o valor total "+num[1][1]+"R$\n"
                        + "A quantidade de leite com café vendido é: "+num[2][0]+"com o valor total "+num[2][1]+"R$\n"
                                + "A quantidade de cafes vendidos e "+(num[0][0]+num[1][0]+num[2][0])+"O total de vendas é: "+total+"R$" );
        
    }
}
