
import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jbasso
 */
public class Q7 {
    public static void main(String[] args) throws IOException {
        String s="",nome;
        DataInputStream dados;
        float peso=0;
        
        System.out.println("Digite o nome do Lutador ");
        dados=new DataInputStream(System.in);
        nome=dados.readLine();
        
        System.out.println("Digite o peso do lutador");
        s=dados.readLine();
        peso=Float.parseFloat(s);
        
        FileWriter arq = new FileWriter("C:\\Users\\jbasso\\Desktop\\prova\\Lutador"+nome+".txt");
        PrintWriter gravaArq = new PrintWriter(arq);
        
        if (peso >99){
            gravaArq.print("O lutador "+nome+" pesa "+peso+"kg e se enquadra na categoria Pesado ");
        }else if (peso>92){
            gravaArq.print("O lutador "+nome+" pesa "+peso+"kg e se enquadra na categoria Meio Pesado ");
        }else if (peso>85){
            gravaArq.print("O lutador "+nome+" pesa "+peso+"kg e se enquadra na categoria Médio ");
        }else if (peso>78){
            gravaArq.print("O lutador "+nome+" pesa "+peso+"kg e se enquadra na categoria Meio Médio ");
        }else if (peso>71){
            gravaArq.print("O lutador "+nome+" pesa "+peso+"kg e se enquadra na categoria Ligeiro ");
        }else if (peso>64){
            gravaArq.print("O lutador "+nome+" pesa "+peso+"kg e se enquadra na categoria Leve ");
        }else{
            gravaArq.print("O lutador "+nome+" pesa "+peso+"kg e se enquadra na categoria Pena ");
        }
        
        arq.close();
        System.out.println("Arquivo Salvo com sucesso  no caminho C:\\Users\\jbasso\\Desktop\\prova\\Lutador"+nome+".txt");
    }
}
