
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jbasso
 */
public class Q3 {
            public static void main(String[] args) {
        String s="";
        int num ;
        s=JOptionPane.showInputDialog(null,"Digite uma numero para verificarmos o antecessor e sucessor");
        num=Integer.parseInt(s);
        
        JOptionPane.showMessageDialog(null, "O antecessor de "+num+" é:"+(num-1)+"\nO sucessor de "+num+" é: "+(num+1));
    }
    
}
