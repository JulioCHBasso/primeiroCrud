
import java.io.DataInputStream;
import java.io.IOException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jbasso
 */
public class Q5 {
    public static void main(String[] args) throws IOException {
        String s="";
        DataInputStream dados;
        float n=0,soma=0,media=0;
        int i=0;
        do{
            System.out.println("Digite um numero \nDigite 0 para sair");
            dados=new DataInputStream(System.in);
            s=dados.readLine();
            n = Float.parseFloat(s);
            soma+=n;
            i++;
        
        }while(n!=0);
        media=soma/i;
        System.out.println("A quantidade de valores digitados é: "+i);
        System.out.println("A soma dos valores digitados é: "+soma);
        System.out.println("A media dos valores digitados é: "+media);
    }
    
}
