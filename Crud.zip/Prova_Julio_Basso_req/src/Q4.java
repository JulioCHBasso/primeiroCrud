
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jbasso
 */
public class Q4 {
    public static void main(String[] args) {
        String s="";
        String senhaR="9999";
       
        String usuR="1234";
      
        
        s=JOptionPane.showInputDialog(null,"Digite seu código de usuário");
        if (s.equalsIgnoreCase(usuR)){
            s=JOptionPane.showInputDialog(null,"Digite sua senha");
            if(s.equalsIgnoreCase(senhaR)){
                JOptionPane.showMessageDialog(null, "Acesso Permitido");
            }else{
                JOptionPane.showMessageDialog(null, "Senha Invalida!!");
            
            }
            
        
        }else {
            JOptionPane.showMessageDialog(null, "Usuário inválido!’");
        
        
        }
                
    }
    
}
