
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jbasso
 */
public class Q6 {
    public static void main(String[] args) {
        String s ="";
        int n = 0;
        String nome[] = new String[2];
        String pergunta[] = new String[2];
        String resposta;
        String res;
        int ponto1=0,ponto2=0;
        do{
        nome[0]=JOptionPane.showInputDialog(null,"Digite o nome do primeiro Jogado");
        resposta=JOptionPane.showInputDialog(null,"Digite o nome do Filme");
        for(int i=0;i<2;i++){
            pergunta[i]=JOptionPane.showInputDialog(null,"Digite a "+i+" pista");
        }
        
        nome[1]=JOptionPane.showInputDialog(null,"Digite o nome da oponente!!/n");
        
        JOptionPane.showMessageDialog(null,"Primeira Pista!!!");
        JOptionPane.showMessageDialog(null,pergunta[0]);
        res = JOptionPane.showInputDialog("Qual o Nome do filme");
        if(resposta.equalsIgnoreCase(res)){
        JOptionPane.showMessageDialog(null, nome[1]+" Acertou ");
        }else {
            JOptionPane.showMessageDialog(null, nome[1]+" erro o nome do filme");
            JOptionPane.showMessageDialog(null,"segunda Pista");
            JOptionPane.showMessageDialog(null,pergunta[1]);
            res = JOptionPane.showInputDialog("Qual o Nome do filme");
           if(resposta.equalsIgnoreCase(res)){
               JOptionPane.showMessageDialog(null, nome[1]+" Acertou ");
               ponto2++;
               }else{
               JOptionPane.showMessageDialog(null, nome[1]+" erro o nome do filme");
               JOptionPane.showMessageDialog(null, "O nome do filme é "+resposta);
               ponto1++;
               
           }
        
        }
        JOptionPane.showMessageDialog(null, "O Jogador "+nome[0]+"tem "+ponto1+"pontos\n"
                + "O Jogador "+nome[1]+"tem "+ponto2+"pontos\n");
        s=JOptionPane.showInputDialog(null,"Deseja sair Digite zero\n ou qualuqer outro numero para continuar jogando ");
        n=Integer.parseInt(s);
        
      
        }while(n!=0);
                
    }
}
